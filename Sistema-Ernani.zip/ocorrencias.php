<?php
include 'config.php';
echo '<h2>Gerenciar Ocorrências</h2>';
?>