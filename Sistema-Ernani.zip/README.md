# Sistema de Ocorrências Escolares - Ernani

Sistema web em PHP + MySQL para gerenciamento de alunos e ocorrências escolares.