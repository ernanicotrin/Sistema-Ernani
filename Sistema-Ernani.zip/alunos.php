<?php
include 'config.php';
echo '<h2>Gerenciar Alunos</h2>';
?>