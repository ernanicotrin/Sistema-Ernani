<?php
include 'config.php';
header('Location: painel.php');
?>